#!/bin/bash
echo "================= Update Both 1st + 2nd BIOS Region ================"
./f.sh
declare -i EXIT_STATUS="$?"
if [ $EXIT_STATUS -ne 0 ]; then
	if [ "$EXIT_STATUS" -ne 100 ]; then
		echo "============ Update 1st BIOS + ME FAIL ============="
	else
		./afulnx_64 /OEMCMD:2B
		echo "============ Update Both 1st + 2nd BIOS Region Complete ========="
	fi
else
	./afulnx_64 /OEMCMD:2B
	echo "============ Update Both 1st + 2nd BIOS Region Complete ========="
fi
